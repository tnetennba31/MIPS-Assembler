#include "normalize.h"
#include "parseString.h"
#include "format_instructions.h"
#include "converttobinthenhex.h"
