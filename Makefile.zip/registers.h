#include "project.h"

int decode_register(char reg_str[]);
