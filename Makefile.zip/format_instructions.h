#include "project.h"

uint32_t format_rtype(parsed_t *parsed);
uint32_t format_itype(parsed_t *parsed);
uint32_t format_jtype(parsed_t *parsed);
