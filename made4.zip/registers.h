#ifndef _REGISTERS_H
#define _REGISTERS_H

#include "project.h"

int decode_register(char reg_str[]);

#endif