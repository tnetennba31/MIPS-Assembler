#ifndef _VALIDATEINSTRUCTION_H
#define _VALIDATEINSTRUCTION_H

#include "project.h"

void validate_instruction(char str[], instr_t_pointer result);

#endif
