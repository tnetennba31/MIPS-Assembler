#ifndef _MAIN_H
#define _MAIN_H

#include "normalize.h"
#include "parseString.h"
#include "format_instructions.h"

#endif
