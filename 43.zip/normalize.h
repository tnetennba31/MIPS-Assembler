#ifndef _NORMALIZE_H
#define _NORMALIZE_H

char *normalize(const char *string);

#endif
